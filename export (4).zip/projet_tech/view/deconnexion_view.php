<html>
<head>
    <link type="text/css" rel="stylesheet" href="../view/css.css">
    <title>Projet Technologique</title>
</head>

    <body>
        <div>
            <h1> Déconnexion </h1>
            <p>
            Vous êtes à présent déconnecté <br />
            Cliquez <a href="../view/index_view.php">ici</a> pour revenir à la page principale
            </p>
        </div>
    </body>
</html>
