
<html>

<head>
    <link type="text/css" rel="stylesheet" href="./view/css.css">
    <title>Projet Technologique</title>
</head>

<body>
    <header>
            <div id="titre_principal">
                <div id="logo">
                    <h1><a href="./view/index_view.php">Marmitiff</a></h1>    
                </div>
            </div>
            
            <nav>
                <ul>
                    <li><a href="./controler/register.php">Inscription</a></li>
                    <li><a href="./controler/connexion.php">Connexion</a></li>
                    <li><a href="./controler/deconnexion.php">Déconnexion</a></li>
                    <li><a href="./controler/new_recette.php">Nouvelle Recette</a></li>
                    <li><a href="./controler/recettes.php">Les recettes</a></li>
                </ul>
            </nav>
        </header>

        <div id="banniere_image">
        
        </div>
</body>

</html>
