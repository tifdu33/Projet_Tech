<?php 
require('../model/une_recette_model.php');
require('../view/une_recette_view.php');