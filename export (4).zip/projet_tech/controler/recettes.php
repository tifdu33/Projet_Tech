<?php 
require('../model/recettes_model.php');
require('../view/recettes_view.php');