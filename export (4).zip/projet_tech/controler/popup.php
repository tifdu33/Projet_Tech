<?php 
require('../model/popup_model.php');
require('../view/popup_view.php');