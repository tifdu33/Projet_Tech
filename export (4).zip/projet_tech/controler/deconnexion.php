<?php
require('../model/deconnexion_model.php');
require('../view/deconnexion_view.php');

