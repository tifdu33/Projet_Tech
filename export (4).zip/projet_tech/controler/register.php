<?php
require('../model/register_model.php');
require('../view/register_view.php');

