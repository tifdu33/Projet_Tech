<?php 
require('../model/new_recette_model.php');
require('../view/new_recette_view.php');