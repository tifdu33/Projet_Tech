<?php 
require('../model/type_recettes_model.php');
require('../view/type_recettes_view.php');