<?php 
require('../model/confirm_email_model.php');
require('../view/confirm_email_view.php');