<?php
function erreur($err='')
{
   $mess=($err!='')? $err:'Une erreur inconnue s\'est produite';
   exit('<p>'.$mess.'</p>
   <p>Cliquez <a href="../view/index_view.php">ici</a> pour revenir à la page d\'accueil</p></div></body></html>');
}

