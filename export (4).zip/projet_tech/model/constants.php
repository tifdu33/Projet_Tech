<?php
define('ERR_IS_NOT_CO','Vous ne pouvez pas accéder à cette page si vous n\'êtes pas connecté');
define('ERR_IS_CO','Vous ne pouvez pas accéder à cette page si vous êtes déjà connecté');

